import { useState } from "react";
import Navigation from "@/components/Navigation";

/**
 * Hacking Page
 * Design: Modern Minimalist with Warm Accents
 * - Masonry post-it wall layout
 * - Click to expand modal with full project details
 * - Photos, descriptions, links, and keywords in modal
 * - 5 personal projects
 */

interface HackingProject {
  id: number;
  name: string;
  keywords: string[];
  shortDescription: string;
  fullDescription: string;
  images: string[];
  links: { label: string; url: string }[];
  technologies: string[];
}

const projects: HackingProject[] = [
  {
    id: 1,
    name: "AI Chat Assistant",
    keywords: ["AI", "NLP", "Web"],
    shortDescription: "Intelligent conversational AI",
    fullDescription:
      "Built a full-stack AI chat assistant using React and Node.js with OpenAI integration. Features real-time messaging, conversation history, and custom prompt engineering. Deployed on Vercel with serverless functions.",
    images: [
      "https://via.placeholder.com/300x200?text=Chat+UI",
      "https://via.placeholder.com/300x200?text=Dashboard",
    ],
    links: [
      { label: "Live Demo", url: "#" },
      { label: "GitHub", url: "#" },
    ],
    technologies: ["React", "Node.js", "OpenAI API", "Tailwind CSS"],
  },
  {
    id: 2,
    name: "Data Visualization Tool",
    keywords: ["Data", "Visualization", "D3.js"],
    shortDescription: "Interactive data visualization platform",
    fullDescription:
      "Created an interactive data visualization platform using D3.js and React. Supports multiple chart types, real-time data updates, and custom color schemes. Includes CSV import and export functionality.",
    images: [
      "https://via.placeholder.com/300x200?text=Charts",
      "https://via.placeholder.com/300x200?text=Analytics",
    ],
    links: [
      { label: "Try It", url: "#" },
      { label: "GitHub", url: "#" },
    ],
    technologies: ["D3.js", "React", "TypeScript", "Express"],
  },
  {
    id: 3,
    name: "Mobile App Framework",
    keywords: ["Mobile", "React Native", "Cross-platform"],
    shortDescription: "Cross-platform mobile development",
    fullDescription:
      "Developed a reusable React Native framework for rapid mobile app development. Includes pre-built components, state management, and API integration patterns. Used in 3 production apps.",
    images: [
      "https://via.placeholder.com/300x200?text=Mobile+UI",
      "https://via.placeholder.com/300x200?text=Components",
    ],
    links: [
      { label: "Documentation", url: "#" },
      { label: "GitHub", url: "#" },
    ],
    technologies: ["React Native", "Redux", "Firebase", "TypeScript"],
  },
  {
    id: 4,
    name: "Blockchain Wallet",
    keywords: ["Blockchain", "Web3", "Crypto"],
    shortDescription: "Secure cryptocurrency wallet",
    fullDescription:
      "Built a secure Web3 wallet application with hardware wallet support. Features multi-signature transactions, DeFi integration, and real-time price tracking. Passed security audit.",
    images: [
      "https://via.placeholder.com/300x200?text=Wallet+Interface",
      "https://via.placeholder.com/300x200?text=Transactions",
    ],
    links: [
      { label: "GitHub", url: "#" },
      { label: "Docs", url: "#" },
    ],
    technologies: ["Solidity", "Web3.js", "React", "Ethers.js"],
  },
  {
    id: 5,
    name: "Game Engine",
    keywords: ["Game Dev", "Graphics", "3D"],
    shortDescription: "Lightweight 3D game engine",
    fullDescription:
      "Created a lightweight 3D game engine using WebGL and Three.js. Supports physics simulation, particle effects, and asset loading. Includes editor tools for level design.",
    images: [
      "https://via.placeholder.com/300x200?text=Game+Scene",
      "https://via.placeholder.com/300x200?text=Editor",
    ],
    links: [
      { label: "Play Demo", url: "#" },
      { label: "GitHub", url: "#" },
    ],
    technologies: ["Three.js", "WebGL", "Cannon.js", "TypeScript"],
  },
];

export default function Hacking() {
  const [selectedProject, setSelectedProject] = useState<HackingProject | null>(
    null
  );

  return (
    <div className="min-h-screen bg-alice-blue pt-24">
      <Navigation />

      <main className="max-w-7xl mx-auto px-6 py-16">
        <h1 className="font-display text-5xl md:text-6xl font-bold text-blue-state mb-16">
          Personal Projects
        </h1>

        {/* Post-it Wall Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {projects.map((project, index) => (
            <div
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="p-6 bg-white rounded-lg shadow-soft smooth-transition hover-lift cursor-pointer"
              style={{
                transform: `rotate(${index % 2 === 0 ? -2 : 2}deg)`,
              }}
            >
              {/* Post-it Content */}
              <h3 className="font-display text-xl font-bold text-blue-state mb-2">
                {project.name}
              </h3>
              <p className="font-body text-sm text-blue-state mb-4 leading-relaxed">
                {project.shortDescription}
              </p>

              {/* Keywords */}
              <div className="flex flex-wrap gap-2">
                {project.keywords.map((keyword) => (
                  <span
                    key={keyword}
                    className="px-2 py-1 bg-tangerine-dream/20 text-tangerine-dream font-nav text-xs font-semibold rounded"
                  >
                    {keyword}
                  </span>
                ))}
              </div>

              {/* Click Indicator */}
              <p className="font-nav text-xs text-muted-foreground mt-4">
                Click to expand →
              </p>
            </div>
          ))}
        </div>
      </main>

      {/* Modal Overlay */}
      {selectedProject && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 smooth-transition-lg"
          onClick={() => setSelectedProject(null)}
        >
          {/* Modal Content */}
          <div
            className="bg-white rounded-lg shadow-medium max-w-2xl w-full max-h-[90vh] overflow-y-auto smooth-transition-lg"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <div className="sticky top-0 flex justify-end p-4 bg-white border-b border-border">
              <button
                onClick={() => setSelectedProject(null)}
                className="text-2xl font-bold text-blue-state hover:text-tangerine-dream smooth-transition"
              >
                ×
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-8 space-y-6">
              {/* Title */}
              <h2 className="font-display text-3xl font-bold text-blue-state">
                {selectedProject.name}
              </h2>

              {/* Images */}
              <div className="grid grid-cols-2 gap-4">
                {selectedProject.images.map((image, idx) => (
                  <img
                    key={idx}
                    src={image}
                    alt={`${selectedProject.name} ${idx + 1}`}
                    className="w-full h-40 object-cover rounded-lg shadow-soft"
                  />
                ))}
              </div>

              {/* Description */}
              <p className="font-body text-blue-state leading-relaxed text-lg">
                {selectedProject.fullDescription}
              </p>

              {/* Technologies */}
              <div>
                <h3 className="font-display text-lg font-bold text-blue-state mb-3">
                  Technologies
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-tropical-teal/10 text-tropical-teal font-nav text-xs font-semibold rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Keywords */}
              <div>
                <h3 className="font-display text-lg font-bold text-blue-state mb-3">
                  Keywords
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.keywords.map((keyword) => (
                    <span
                      key={keyword}
                      className="px-3 py-1 bg-tangerine-dream/10 text-tangerine-dream font-nav text-xs font-semibold rounded-full"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>

              {/* Links */}
              <div className="flex gap-4 pt-4">
                {selectedProject.links.map((link) => (
                  <a
                    key={link.label}
                    href={link.url}
                    className="px-6 py-2 bg-tropical-teal text-white font-nav font-semibold text-sm rounded-lg smooth-transition hover:bg-blue-state shadow-soft hover:shadow-medium"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
