import Navigation from "@/components/Navigation";

/**
 * Research Page
 * Design: Modern Minimalist with Warm Accents
 * - Full-width section headers
 * - Left column (25%): Images in flowchart-style layout
 * - Right column (70%): Project descriptions and links
 * - 4 research projects with alternating layouts
 */

interface ResearchProject {
  id: number;
  title: string;
  year: string;
  description: string;
  images: string[];
  links: { label: string; url: string }[];
  keywords: string[];
}

const projects: ResearchProject[] = [
  {
    id: 1,
    title: "Advanced Machine Learning in Healthcare",
    year: "2023",
    description:
      "This research project explores the application of deep learning models for early disease detection. We developed a novel CNN architecture that achieves 94% accuracy on medical imaging datasets. The work involved collaboration with leading medical institutions and resulted in three peer-reviewed publications.",
    images: [
      "https://via.placeholder.com/200x150?text=ML+Model",
      "https://via.placeholder.com/200x150?text=Data+Analysis",
      "https://via.placeholder.com/200x150?text=Results",
    ],
    links: [
      { label: "View Paper", url: "#" },
      { label: "GitHub", url: "#" },
    ],
    keywords: ["Machine Learning", "Healthcare", "Deep Learning", "CNN"],
  },
  {
    id: 2,
    title: "Quantum Computing Applications",
    year: "2023",
    description:
      "Investigating practical applications of quantum computing in optimization problems. This research demonstrates how quantum algorithms can solve certain NP-hard problems more efficiently than classical approaches. We implemented simulations on IBM Quantum Experience and published findings in top-tier conferences.",
    images: [
      "https://via.placeholder.com/200x150?text=Quantum+Circuit",
      "https://via.placeholder.com/200x150?text=Simulation",
      "https://via.placeholder.com/200x150?text=Performance",
    ],
    links: [
      { label: "View Paper", url: "#" },
      { label: "IBM Quantum", url: "#" },
    ],
    keywords: ["Quantum Computing", "Optimization", "Algorithms"],
  },
  {
    id: 3,
    title: "Natural Language Processing for Code Generation",
    year: "2022",
    description:
      "Developing transformer-based models for automatic code generation from natural language descriptions. This work bridges the gap between human intent and executable code, with applications in software development productivity. The model was trained on millions of code samples and achieves state-of-the-art results on benchmark datasets.",
    images: [
      "https://via.placeholder.com/200x150?text=NLP+Model",
      "https://via.placeholder.com/200x150?text=Training+Data",
      "https://via.placeholder.com/200x150?text=Evaluation",
    ],
    links: [
      { label: "View Paper", url: "#" },
      { label: "Model Demo", url: "#" },
    ],
    keywords: ["NLP", "Code Generation", "Transformers", "AI"],
  },
  {
    id: 4,
    title: "Sustainable Energy Grid Optimization",
    year: "2022",
    description:
      "Researching intelligent algorithms for optimizing renewable energy distribution in smart grids. This interdisciplinary project combines electrical engineering, computer science, and environmental science to create more efficient and sustainable energy systems. Results show 23% improvement in energy utilization.",
    images: [
      "https://via.placeholder.com/200x150?text=Grid+Analysis",
      "https://via.placeholder.com/200x150?text=Optimization",
      "https://via.placeholder.com/200x150?text=Impact",
    ],
    links: [
      { label: "View Paper", url: "#" },
      { label: "Data Dashboard", url: "#" },
    ],
    keywords: ["Energy", "Optimization", "Sustainability", "IoT"],
  },
];

export default function Research() {
  return (
    <div className="min-h-screen bg-alice-blue pt-24">
      <Navigation />

      <main className="max-w-7xl mx-auto px-6 py-16">
        <h1 className="font-display text-5xl md:text-6xl font-bold text-blue-state mb-16">
          Research Projects
        </h1>

        {/* Research Projects */}
        {projects.map((project, index) => (
          <div key={project.id} className="mb-20">
            {/* Section Header */}
            <div className="mb-8 pb-4 border-b-2 border-tangerine-dream">
              <h2 className="font-display text-3xl md:text-4xl font-bold text-blue-state">
                {project.title}
              </h2>
              <p className="font-nav text-sm text-tropical-teal font-semibold mt-2">
                {project.year}
              </p>
            </div>

            {/* Two-Column Layout */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Left Column: Images (25%) */}
              <div className="md:col-span-1 space-y-4">
                <div className="space-y-3">
                  {project.images.map((image, imgIndex) => (
                    <div
                      key={imgIndex}
                      className="relative aspect-square rounded-lg overflow-hidden shadow-soft hover:shadow-medium smooth-transition"
                    >
                      <img
                        src={image}
                        alt={`${project.title} image ${imgIndex + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
                {/* Flowchart-style connector */}
                {index < projects.length - 1 && (
                  <div className="flex justify-center pt-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-tropical-teal to-transparent"></div>
                  </div>
                )}
              </div>

              {/* Right Column: Description (70%) */}
              <div className="md:col-span-3 space-y-6">
                <p className="font-body text-blue-state leading-relaxed text-lg">
                  {project.description}
                </p>

                {/* Keywords */}
                <div className="flex flex-wrap gap-2">
                  {project.keywords.map((keyword) => (
                    <span
                      key={keyword}
                      className="px-3 py-1 bg-tropical-teal/10 text-tropical-teal font-nav text-xs font-semibold rounded-full"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-4 pt-4">
                  {project.links.map((link) => (
                    <a
                      key={link.label}
                      href={link.url}
                      className="px-6 py-2 bg-tropical-teal text-white font-nav font-semibold text-sm rounded-lg smooth-transition hover:bg-blue-state shadow-soft hover:shadow-medium"
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}
