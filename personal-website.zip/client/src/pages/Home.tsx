import { useEffect, useRef, useState } from "react";
import Navigation from "@/components/Navigation";

/**
 * Home Page
 * Design: Modern Minimalist with Warm Accents
 * - Hero section with bio and links
 * - Photo placeholder on the right
 * - Mouse-tracking parallax component
 * - CV button that opens in new tab
 */

interface MousePosition {
  x: number;
  y: number;
}

export default function Home() {
  const [mousePos, setMousePos] = useState<MousePosition>({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;

      setMousePos({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // Calculate parallax offset (subtle effect, max 20px movement)
  const parallaxX = (mousePos.x - 0.5) * 20;
  const parallaxY = (mousePos.y - 0.5) * 20;

  return (
    <div className="min-h-screen bg-alice-blue pt-24">
      <Navigation />

      <main className="max-w-7xl mx-auto px-6 py-16">
        {/* Hero Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left: Bio and Links */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="font-display text-5xl md:text-6xl font-bold text-blue-state">
                Welcome to My
                <span className="block text-accent-warm">Creative Space</span>
              </h1>
              <p className="font-body text-lg text-blue-state leading-relaxed">
                I'm a passionate researcher, developer, and creative thinker exploring the intersection of technology and innovation. This portfolio showcases my research projects, personal hacking endeavors, press features, and hobbies.
              </p>
            </div>

            {/* Links Section */}
            <div className="space-y-4">
              <h3 className="font-display text-xl font-bold text-blue-state">
                Connect with Me
              </h3>
              <div className="flex flex-wrap gap-4">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-tropical-teal text-white font-nav font-semibold rounded-lg smooth-transition hover:bg-blue-state shadow-soft hover:shadow-medium"
                >
                  GitHub
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-tropical-teal text-white font-nav font-semibold rounded-lg smooth-transition hover:bg-blue-state shadow-soft hover:shadow-medium"
                >
                  LinkedIn
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-tropical-teal text-white font-nav font-semibold rounded-lg smooth-transition hover:bg-blue-state shadow-soft hover:shadow-medium"
                >
                  Twitter
                </a>
              </div>
            </div>

            {/* CV Button */}
            <div>
              <a
                href="/cv.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-8 py-4 bg-gradient-accent text-white font-nav font-semibold rounded-lg smooth-transition hover:shadow-medium shadow-soft hover-lift"
              >
                Download CV (PDF)
              </a>
            </div>
          </div>

          {/* Right: Photo with Mouse Tracking */}
          <div
            ref={containerRef}
            className="relative h-96 md:h-[500px] rounded-lg overflow-hidden shadow-medium"
          >
            {/* Mouse-tracking parallax background */}
            <div
              className="absolute inset-0 bg-gradient-to-br from-tropical-teal to-tangerine-dream opacity-10 smooth-transition"
              style={{
                transform: `translate(${parallaxX}px, ${parallaxY}px)`,
              }}
            />

            {/* Photo Placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-tropical-teal/20 to-tangerine-dream/20 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-tropical-teal/30 flex items-center justify-center">
                  <svg
                    className="w-16 h-16 text-tropical-teal"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                  </svg>
                </div>
                <p className="text-blue-state font-body text-sm">
                  Replace with your photo
                </p>
                <p className="text-muted-foreground font-body text-xs mt-2">
                  Move your mouse to see the parallax effect
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Info Section */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-white rounded-lg shadow-soft smooth-transition hover:shadow-medium">
            <h3 className="font-display text-xl font-bold text-blue-state mb-3">
              Research
            </h3>
            <p className="font-body text-blue-state text-sm leading-relaxed">
              Exploring cutting-edge topics through rigorous investigation and publication.
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-soft smooth-transition hover:shadow-medium">
            <h3 className="font-display text-xl font-bold text-blue-state mb-3">
              Projects
            </h3>
            <p className="font-body text-blue-state text-sm leading-relaxed">
              Building innovative solutions and experimenting with new technologies.
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-soft smooth-transition hover:shadow-medium">
            <h3 className="font-display text-xl font-bold text-blue-state mb-3">
              Hobbies
            </h3>
            <p className="font-body text-blue-state text-sm leading-relaxed">
              Pursuing creative interests and personal growth outside of work.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
